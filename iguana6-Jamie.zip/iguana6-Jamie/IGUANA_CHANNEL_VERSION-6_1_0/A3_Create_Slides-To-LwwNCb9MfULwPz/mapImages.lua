function mapImages(msg, slides)
   local body = {}
   body.slideId = slides.id
   
   return body
end

return mapImages