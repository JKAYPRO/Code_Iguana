local gc = require 'globalConfig'
local tzOffset = require 'date.getTimezoneOffset'
local bu = require 'barcodeUtils'
local mapBlockKey = require 'mapBlockKey'
hl7.unescape = require 'hl7.delimiter.unescape'
require 'date.parse'

function parseOML(msg)
   -- Extract and parse the barcode
   -- Replace _ with ^ to match the barcode. "^" not used in the HL7 since that is a reserved character
   local barcode = hl7.unescape(msg.OBR[2]:S()):gsub('_','^') 
   local parsedBarcode = bu.parseBarcode(barcode, gc.BARCODE_FORMAT, gc.BARCODE_COMPONENTS)
   local blockKey = mapBlockKey(parsedBarcode)
   
   local j = {} -- create blank JSON placeholder
   
   -- set message type
   j.messageType = 'upsert'
   
   -- set options
   j.options = gc.MESSAGE_OPTIONS
   
   -- Case Details
   local accessionDate = msg.SAC[7]:S()
   local offset = tzOffset(accessionDate:TIME(), gc.DEFAULT_OFFSET, gc.DST_TRANSITIONS)   
   
   j.case = {}
   j.case.accessionDate = accessionDate:ISO8601(offset)
   j.case.accessionId = parsedBarcode.accessionId
   --j.case.assignedUserCode = msg.OBR[16][1][1]:S() -- TODO: determine how to map assignedUser (Not in scope v1)
   j.case.labSiteId = gc.LAB_SITE
   j.case.patientDob = msg.PID[7]:S():sub(1,8):DAY('yyyymmdd')
   j.case.patientLastName = msg.PID[5][1][1]:S()
   j.case.patientFirstName = msg.PID[5][1][2]:S()
   j.case.patientMrn = msg.PID[3][1][1]:S()
   j.case.patientSex = msg.PID[8][1]:S():sub(1, 1) -- Phoenix will only send Male, Female, or Unknown
   j.case.patientGenderIdentity = j.case.patientSex
   
   -- UDFs
   -- Check if NTE segments exist
   if msg.NTE then
      for i = 1, #msg.NTE do
         if msg.NTE[i][2]:S() == 'Diagnosis' then
            j.case.udf = {}            
            j.case.udf.diagnosis = hl7.unescape(msg.NTE[i][3][1]:S())
            break
         end
      end
   end   
   
   -- Parts
   local part = parsedBarcode.part
   local block = parsedBarcode.block
   
   j.case.parts = {{}}
   j.case.parts[1].blocks = {{key=blockKey,name=block}}
   j.case.parts[1].name = part
   --j.case.parts[1].procedureCode = ''
   --j.case.parts[1].procedureName = ''
   j.case.parts[1].specimenDescription = msg.OBR[15][1]:S()
   j.case.parts[1].specimenCode = msg.OBR[15][1]:S()
   j.case.parts[1].specimenName = msg.OBR[15][1]:S()
   
   -- Slide
   local slide = parsedBarcode.slide
   
   j.case.parts[1].slides = {{}}
   j.case.parts[1].slides[1].barcode = barcode
   j.case.parts[1].slides[1].blockKey = blockKey
   j.case.parts[1].slides[1].name = parsedBarcode.accessionId..'-'..blockKey..'-'..parsedBarcode.slide
   j.case.parts[1].slides[1].stainCode = parsedBarcode.stain
   j.case.parts[1].slides[1].stainName = parsedBarcode.stain
   
   return j
end

return parseOML
