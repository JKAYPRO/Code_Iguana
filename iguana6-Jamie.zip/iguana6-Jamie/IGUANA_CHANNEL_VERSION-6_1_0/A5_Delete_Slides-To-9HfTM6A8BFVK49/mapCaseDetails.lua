function mapCaseDetails(status)
   local body = {}
   body.caseStage = status
   
   return body
end

return mapCaseDetails