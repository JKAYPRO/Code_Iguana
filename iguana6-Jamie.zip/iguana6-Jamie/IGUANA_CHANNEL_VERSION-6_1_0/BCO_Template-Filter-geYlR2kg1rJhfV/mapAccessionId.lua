function mapAccessionId(parsedBarcode)
   return parsedBarcode.accessionId
end

return mapAccessionId