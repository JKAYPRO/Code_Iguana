function mapImages(slides)
   local body = {}
   body.slideId = slides.id
   
   return body
end

return mapImages